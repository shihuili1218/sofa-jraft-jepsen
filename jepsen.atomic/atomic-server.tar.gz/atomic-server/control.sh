nohup java -Xmx512m -Xms512m -jar target/atomic-server-0.1.0-SNAPSHOT-standalone.jar $@ >> atomic.log 2>&1 &
